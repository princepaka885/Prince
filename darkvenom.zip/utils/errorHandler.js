/**
 * Darkvenom v1 - Error Handler Utility
 * Centralized error handling for the bot
 */

const { logger } = require('./logger');

/**
 * Handle an error with appropriate logging and recovery
 * @param {string} context - Description of what was happening when the error occurred
 * @param {Error} error - The error object
 * @param {Object} [options] - Additional options for error handling
 * @param {boolean} [options.fatal=false] - Whether this error is fatal and should terminate the process
 */
function handleError(context, error, options = {}) {
  const { fatal = false } = options;
  
  // Build the error message
  let errorMessage = `${context}: ${error.message}`;
  
  // Log the error with different severity depending on whether it's fatal
  if (fatal) {
    logger.error(`FATAL ERROR: ${errorMessage}`);
  } else {
    logger.error(errorMessage);
  }
  
  // Log the stack trace in debug mode
  logger.debug(`Stack trace: ${error.stack}`);
  
  // Perform any necessary recovery actions
  if (!fatal) {
    // Implement recovery strategies here if applicable
  } else {
    // If the error is fatal, terminate the process after logging
    logger.error('Terminating due to fatal error');
    process.exit(1);
  }
}

/**
 * Wrap an async function with error handling
 * @param {Function} fn - The async function to wrap
 * @param {string} context - Description of the function for error reporting
 * @returns {Function} Wrapped function with error handling
 */
function withErrorHandling(fn, context) {
  return async (...args) => {
    try {
      return await fn(...args);
    } catch (error) {
      handleError(`Error in ${context}`, error);
      return null;
    }
  };
}

/**
 * Create a timeout promise that rejects after a specified time
 * @param {number} ms - Timeout in milliseconds
 * @param {string} operation - Name of the operation for error message
 * @returns {Promise} A promise that rejects after the timeout
 */
function createTimeout(ms, operation) {
  return new Promise((_, reject) => {
    setTimeout(() => {
      reject(new Error(`Operation "${operation}" timed out after ${ms}ms`));
    }, ms);
  });
}

/**
 * Execute a function with a timeout
 * @param {Function} fn - The function to execute
 * @param {number} timeoutMs - Timeout in milliseconds
 * @param {string} operation - Name of the operation
 * @param {...any} args - Arguments to pass to the function
 * @returns {Promise} Result of the function or timeout error
 */
async function executeWithTimeout(fn, timeoutMs, operation, ...args) {
  try {
    return await Promise.race([
      fn(...args),
      createTimeout(timeoutMs, operation)
    ]);
  } catch (error) {
    handleError(`Timeout error in ${operation}`, error);
    throw error;
  }
}

module.exports = {
  handleError,
  withErrorHandling,
  executeWithTimeout,
};
