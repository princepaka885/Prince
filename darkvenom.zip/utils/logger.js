/**
 * Darkvenom v1 - Logger Utility
 * Handles all logging operations for the bot
 */

const fs = require('fs');
const path = require('path');
const config = require('../config');

// ANSI color codes for terminal output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  dim: '\x1b[2m',
  underscore: '\x1b[4m',
  
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  white: '\x1b[37m',
};

// Log levels with their corresponding values
const logLevels = {
  debug: 0,
  info: 1,
  warn: 2,
  error: 3,
  none: 4,
};

// Create logs directory if logging to file is enabled
if (config.logging.logToFile) {
  const logDir = path.dirname(config.logging.logFilePath);
  if (!fs.existsSync(logDir)) {
    try {
      fs.mkdirSync(logDir, { recursive: true });
    } catch (error) {
      console.error(`Failed to create log directory: ${error.message}`);
      config.logging.logToFile = false;
    }
  }
}

/**
 * The main logger object with methods for different log levels
 */
const logger = {
  /**
   * Log a debug message
   * @param {...any} args - Message and additional data to log
   */
  debug: (...args) => {
    if (logLevels[config.logging.level] <= logLevels.debug) {
      const timestamp = getTimestamp();
      console.log(`${colors.dim}${timestamp} DEBUG:${colors.reset}`, ...args);
      writeToLogFile('DEBUG', timestamp, args);
    }
  },
  
  /**
   * Log an informational message
   * @param {...any} args - Message and additional data to log
   */
  info: (...args) => {
    if (logLevels[config.logging.level] <= logLevels.info) {
      const timestamp = getTimestamp();
      console.log(`${colors.cyan}${timestamp} INFO:${colors.reset}`, ...args);
      writeToLogFile('INFO', timestamp, args);
    }
  },
  
  /**
   * Log a success message (a type of info message but with green color)
   * @param {...any} args - Message and additional data to log
   */
  success: (...args) => {
    if (logLevels[config.logging.level] <= logLevels.info) {
      const timestamp = getTimestamp();
      console.log(`${colors.green}${timestamp} SUCCESS:${colors.reset}`, ...args);
      writeToLogFile('SUCCESS', timestamp, args);
    }
  },
  
  /**
   * Log a warning message
   * @param {...any} args - Message and additional data to log
   */
  warn: (...args) => {
    if (logLevels[config.logging.level] <= logLevels.warn) {
      const timestamp = getTimestamp();
      console.log(`${colors.yellow}${timestamp} WARNING:${colors.reset}`, ...args);
      writeToLogFile('WARNING', timestamp, args);
    }
  },
  
  /**
   * Log an error message
   * @param {...any} args - Message and additional data to log
   */
  error: (...args) => {
    if (logLevels[config.logging.level] <= logLevels.error) {
      const timestamp = getTimestamp();
      console.error(`${colors.red}${timestamp} ERROR:${colors.reset}`, ...args);
      writeToLogFile('ERROR', timestamp, args);
    }
  },
};

/**
 * Get a formatted timestamp for log messages
 * @returns {string} Formatted timestamp [YYYY-MM-DD HH:MM:SS]
 */
function getTimestamp() {
  const now = new Date();
  
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const seconds = String(now.getSeconds()).padStart(2, '0');
  
  return `[${year}-${month}-${day} ${hours}:${minutes}:${seconds}]`;
}

/**
 * Write a log message to file if file logging is enabled
 * @param {string} level - Log level
 * @param {string} timestamp - Formatted timestamp
 * @param {Array} args - Log message arguments
 */
function writeToLogFile(level, timestamp, args) {
  if (!config.logging.logToFile) return;
  
  try {
    const message = args.map(arg => {
      if (typeof arg === 'object') {
        return JSON.stringify(arg);
      }
      return String(arg);
    }).join(' ');
    
    const logEntry = `${timestamp} ${level}: ${message}\n`;
    
    fs.appendFileSync(config.logging.logFilePath, logEntry);
  } catch (error) {
    console.error(`Failed to write to log file: ${error.message}`);
  }
}

module.exports = {
  logger,
  colors,
};
