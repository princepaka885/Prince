/**
 * Darkvenom v1 - Command Parser Utility
 * Parses user input into command and arguments
 */

const config = require('../config');

/**
 * Parse a command string into command name and arguments
 * @param {string} input - Raw user input
 * @returns {Object} Object containing command name and arguments array
 */
function parseCommand(input) {
  if (!input || typeof input !== 'string') {
    return { command: null, args: [] };
  }
  
  // Remove leading/trailing whitespace
  const trimmedInput = input.trim();
  
  // Handle prefixed commands (for future platform integration)
  if (trimmedInput.startsWith(config.commandPrefix)) {
    const withoutPrefix = trimmedInput.slice(config.commandPrefix.length);
    return parseCommandParts(withoutPrefix);
  }
  
  // Handle normal commands (no prefix needed in console mode)
  return parseCommandParts(trimmedInput);
}

/**
 * Parse a command string into command and arguments
 * @param {string} input - Command string without prefix
 * @returns {Object} Object containing command name and arguments array
 */
function parseCommandParts(input) {
  // Split by whitespace but respect quoted arguments
  const parts = splitWithQuotes(input);
  
  if (parts.length === 0) {
    return { command: null, args: [] };
  }
  
  // First part is the command, the rest are arguments
  const command = parts[0].toLowerCase();
  const args = parts.slice(1);
  
  return { command, args };
}

/**
 * Split a string by whitespace but respect quoted sections
 * @param {string} input - Input string to split
 * @returns {string[]} Array of parts
 */
function splitWithQuotes(input) {
  if (!input) return [];
  
  const result = [];
  let current = '';
  let inQuotes = false;
  let quoteChar = '';
  
  for (let i = 0; i < input.length; i++) {
    const char = input[i];
    
    // Handle quotes
    if ((char === '"' || char === "'") && (i === 0 || input[i - 1] !== '\\')) {
      if (inQuotes && char === quoteChar) {
        // End of quoted section
        inQuotes = false;
        quoteChar = '';
      } else if (!inQuotes) {
        // Start of quoted section
        inQuotes = true;
        quoteChar = char;
      } else {
        // Different quote character inside quotes, treat as normal character
        current += char;
      }
      continue;
    }
    
    // Handle whitespace
    if (/\s/.test(char) && !inQuotes) {
      if (current) {
        result.push(current);
        current = '';
      }
      continue;
    }
    
    // Add character to current part
    current += char;
  }
  
  // Add the last part if it exists
  if (current) {
    result.push(current);
  }
  
  return result;
}

module.exports = {
  parseCommand,
};
