/**
 * Darkvenom v1 - Shutdown Events
 * Code to execute when the bot is shutting down
 */

const { logger } = require('../utils/logger');

/**
 * Execute shutdown procedures
 * @param {Object} botState - Current state of the bot
 */
async function executeShutdown(botState) {
  // Calculate runtime
  const runtime = calculateRuntime(botState.startTime);
  logger.info(`Bot was running for ${runtime}`);
  
  // Clean up resources
  await cleanupResources();
  
  // Save any necessary state
  await saveState(botState);
  
  // Display goodbye message
  displayGoodbyeMessage();
}

/**
 * Calculate the total runtime of the bot
 * @param {Date} startTime - When the bot started
 * @returns {String} Formatted runtime
 */
function calculateRuntime(startTime) {
  if (!startTime) return 'unknown time';
  
  const runtimeMs = Date.now() - startTime.getTime();
  
  const seconds = Math.floor(runtimeMs / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  
  if (hours > 0) {
    return `${hours}h ${minutes % 60}m ${seconds % 60}s`;
  } else if (minutes > 0) {
    return `${minutes}m ${seconds % 60}s`;
  } else {
    return `${seconds}s`;
  }
}

/**
 * Clean up any resources before shutting down
 */
async function cleanupResources() {
  logger.info('Cleaning up resources...');
  
  // Close any open connections, file handles, etc.
  
  // Simulate cleanup with a small delay
  await new Promise(resolve => setTimeout(resolve, 300));
  
  logger.info('Resources cleaned up successfully');
}

/**
 * Save bot state before shutting down
 * @param {Object} botState - Current state of the bot
 */
async function saveState(botState) {
  logger.info('Saving bot state...');
  
  // In a real implementation, this would save state to a file or database
  
  // Simulate state saving with a small delay
  await new Promise(resolve => setTimeout(resolve, 200));
  
  logger.info('Bot state saved successfully');
}

/**
 * Display a goodbye message
 */
function displayGoodbyeMessage() {
  logger.info('Thank you for using Darkvenom v1. Goodbye!');
}

module.exports = {
  executeShutdown,
};
