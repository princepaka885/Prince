/**
 * Darkvenom v1 - Events Manager
 * Handles bot lifecycle events
 */

const { executeStartup } = require('./startup');
const { executeShutdown } = require('./shutdown');
const { logger } = require('../utils/logger');
const { handleError } = require('../utils/errorHandler');

/**
 * Execute all startup events
 * @param {Object} botState - Current state of the bot
 */
async function executeStartupEvents(botState) {
  try {
    logger.info('Executing startup events...');
    await executeStartup(botState);
    logger.info('Startup events completed');
  } catch (error) {
    handleError('Failed to execute startup events', error);
  }
}

/**
 * Execute all shutdown events
 * @param {Object} botState - Current state of the bot
 */
async function executeShutdownEvents(botState) {
  try {
    logger.info('Executing shutdown events...');
    await executeShutdown(botState);
    logger.info('Shutdown events completed');
  } catch (error) {
    handleError('Failed to execute shutdown events', error);
  }
}

module.exports = {
  executeStartupEvents,
  executeShutdownEvents,
};
