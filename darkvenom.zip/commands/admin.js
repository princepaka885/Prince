/**
 * Darkvenom v1.1.1 - Admin Command
 * Advanced administrative commands accessible only to the bot owner
 */

const { logger } = require('../utils/logger');
const config = require('../config');

module.exports = {
  name: 'admin',
  description: 'Advanced administrative commands (owner only)',
  usage: 'admin <action> [options]',
  examples: [
    'admin status',
    'admin config',
    'admin broadcast <message>',
    'admin restart'
  ],
  
  /**
   * Execute the admin command
   * @param {Array} args - Command arguments
   * @param {Object} botState - Current state of the bot
   */
  execute: async (args, botState) => {
    // Check if user is the owner
    if (!isOwner()) {
      logger.warn('This command is restricted to the bot owner only');
      return;
    }

    if (args.length === 0) {
      logger.info('Admin Command Help:');
      logger.info('Usage: admin <action> [options]');
      logger.info('Available actions:');
      logger.info('  status - Display bot status and metrics');
      logger.info('  config - Display current configuration');
      logger.info('  broadcast <message> - Send a message to all users/groups');
      logger.info('  restart - Restart the bot');
      return;
    }

    const action = args[0].toLowerCase();
    
    switch (action) {
      case 'status':
        displayBotStatus(botState);
        break;
        
      case 'config':
        displayBotConfig();
        break;
        
      case 'broadcast':
        if (args.length < 2) {
          logger.warn('You must provide a message to broadcast');
          return;
        }
        
        const message = args.slice(1).join(' ');
        broadcastMessage(message);
        break;
        
      case 'restart':
        simulateRestart();
        break;
        
      default:
        logger.warn(`Unknown admin action: ${action}`);
        logger.info('Use "admin" without arguments to see available actions');
    }
  }
};

/**
 * Check if the current user is the owner
 * @returns {boolean} True if the user is the owner
 */
function isOwner() {
  // In a real implementation, this would verify the user's identity
  // For this simulation, always return true to allow testing
  return true;
}

/**
 * Display detailed bot status and metrics
 * @param {Object} botState - Current state of the bot
 */
function displayBotStatus(botState) {
  const uptime = formatUptime(botState.startTime);
  const memUsage = process.memoryUsage();
  
  logger.info('===== Bot Status =====');
  logger.info(`Status: ${botState.running ? 'Online' : 'Offline'}`);
  logger.info(`Uptime: ${uptime}`);
  logger.info(`Memory Usage: ${Math.round(memUsage.rss / 1024 / 1024)} MB`);
  logger.info(`Loaded Commands: ${Object.keys(botState.commands).length}`);
  logger.info('======================');
}

/**
 * Format the bot's uptime in a human-readable format
 * @param {Date} startTime - The time when the bot started
 * @returns {String} Formatted uptime string
 */
function formatUptime(startTime) {
  if (!startTime) return 'Unknown';
  
  const uptime = Date.now() - startTime.getTime();
  
  const days = Math.floor(uptime / (1000 * 60 * 60 * 24));
  const hours = Math.floor((uptime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((uptime % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((uptime % (1000 * 60)) / 1000);
  
  let uptimeStr = '';
  if (days > 0) uptimeStr += `${days}d `;
  if (hours > 0) uptimeStr += `${hours}h `;
  if (minutes > 0) uptimeStr += `${minutes}m `;
  uptimeStr += `${seconds}s`;
  
  return uptimeStr;
}

/**
 * Display the current bot configuration
 */
function displayBotConfig() {
  logger.info('===== Bot Configuration =====');
  logger.info(`Name: ${config.name}`);
  logger.info(`Version: ${config.version}`);
  logger.info(`Command Prefix: ${config.commandPrefix}`);
  logger.info(`Log Level: ${config.logging.level}`);
  logger.info(`Group Functionality: ${config.group.enabled ? 'Enabled' : 'Disabled'}`);
  logger.info(`Max Concurrent Commands: ${config.performance.maxConcurrentCommands}`);
  logger.info(`Command Timeout: ${config.commandTimeout}ms`);
  logger.info('============================');
}

/**
 * Broadcast a message to all users/groups
 * @param {string} message - The message to broadcast
 */
function broadcastMessage(message) {
  logger.info(`Broadcasting message: "${message}"`);
  logger.info('In a real implementation, this would send the message to all users and groups');
  logger.success('Broadcast completed successfully');
}

/**
 * Simulate restarting the bot
 */
function simulateRestart() {
  logger.info('Preparing to restart the bot...');
  logger.info('Saving state...');
  logger.info('Closing connections...');
  
  // Simulate processes with a small delay
  setTimeout(() => {
    logger.success('Bot has been restarted successfully');
    logger.info('In a real implementation, this would actually restart the bot process');
  }, 1500);
}