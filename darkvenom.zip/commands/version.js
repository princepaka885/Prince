/**
 * Darkvenom v1.1.1 - Version Command
 * Displays information about the bot version
 */

const { logger } = require('../utils/logger');
const config = require('../config');

module.exports = {
  name: 'version',
  description: 'Display information about the bot version',
  usage: 'version',
  
  /**
   * Execute the version command
   * @param {Array} args - Command arguments
   * @param {Object} botState - Current state of the bot
   */
  execute: async (args, botState) => {
    logger.info('===== Bot Version Information =====');
    logger.info(`Bot: ${config.name}`);
    logger.info(`Current Version: ${config.version}`);
    logger.info('Release Date: May 8, 2025');
    logger.info('');
    logger.info('Version History:');
    logger.info('v1.1.1 - Added group commands, owner information');
    logger.info('v1.0.0 - Initial release with basic commands');
    logger.info('==================================');
  }
};