/**
 * Darkvenom v1 - Ping Command
 * Checks if the bot is responsive and returns latency
 */

const { logger } = require('../utils/logger');

module.exports = {
  name: 'ping',
  description: 'Check if the bot is responsive and measure latency',
  usage: 'ping',
  
  /**
   * Execute the ping command
   * @param {Array} args - Command arguments
   * @param {Object} botState - Current state of the bot
   */
  execute: async (args, botState) => {
    const startTime = Date.now();
    
    // Simulate a small delay to measure "latency"
    await new Promise(resolve => setTimeout(resolve, 100));
    
    const latency = Date.now() - startTime;
    
    logger.info(`Pong! Latency: ${latency}ms`);
    logger.info(`Bot uptime: ${formatUptime(botState.startTime)}`);
  }
};

/**
 * Format the bot's uptime in a human-readable format
 * @param {Date} startTime - The time when the bot started
 * @returns {String} Formatted uptime string
 */
function formatUptime(startTime) {
  if (!startTime) return 'Unknown';
  
  const uptime = Date.now() - startTime.getTime();
  
  const days = Math.floor(uptime / (1000 * 60 * 60 * 24));
  const hours = Math.floor((uptime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((uptime % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((uptime % (1000 * 60)) / 1000);
  
  let uptimeStr = '';
  if (days > 0) uptimeStr += `${days}d `;
  if (hours > 0) uptimeStr += `${hours}h `;
  if (minutes > 0) uptimeStr += `${minutes}m `;
  uptimeStr += `${seconds}s`;
  
  return uptimeStr;
}
