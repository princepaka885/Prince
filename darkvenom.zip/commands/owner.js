/**
 * Darkvenom v1 - Owner Command
 * Displays information about the bot owner
 */

const { logger } = require('../utils/logger');
const config = require('../config');

module.exports = {
  name: 'owner',
  description: 'Display information about the bot owner',
  usage: 'owner',
  
  /**
   * Execute the owner command
   * @param {Array} args - Command arguments
   * @param {Object} botState - Current state of the bot
   */
  execute: async (args, botState) => {
    logger.info('===== Bot Owner Information =====');
    
    if (config.owner) {
      logger.info(`Name: ${config.owner.name}`);
      logger.info(`Contact: ${config.owner.phoneNumber}`);
      logger.info(`Global Owner Status: ${config.owner.isGlobalOwner ? 'Global Owner' : 'Owner'}`);
    } else {
      logger.warn('Owner information not configured');
    }
    
    logger.info('===============================');
  }
};