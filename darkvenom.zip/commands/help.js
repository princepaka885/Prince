/**
 * Darkvenom v1 - Help Command
 * Provides information about available commands
 */

const { logger } = require('../utils/logger');

module.exports = {
  name: 'help',
  description: 'Display help information about available commands',
  usage: 'help [command]',
  
  /**
   * Execute the help command
   * @param {Array} args - Command arguments
   * @param {Object} botState - Current state of the bot
   */
  execute: async (args, botState) => {
    const { commands } = botState;
    
    // If a specific command is requested, show detailed help for it
    if (args.length > 0) {
      const commandName = args[0].toLowerCase();
      const command = commands[commandName];
      
      if (command) {
        logger.info(`Command: ${command.name}`);
        logger.info(`Description: ${command.description}`);
        logger.info(`Usage: ${command.usage || command.name}`);
        
        if (command.examples) {
          logger.info('Examples:');
          command.examples.forEach(example => {
            logger.info(`  ${example}`);
          });
        }
      } else {
        logger.warn(`Command "${commandName}" not found.`);
      }
      return;
    }
    
    // Otherwise, show a list of all available commands
    logger.info('=== Darkvenom v1 Help ===');
    logger.info('Available commands:');
    
    Object.values(commands).forEach(command => {
      logger.info(`  ${command.name}: ${command.description}`);
    });
    
    logger.info('\nBuilt-in commands:');
    logger.info('  exit/quit: Shut down the bot');
    logger.info('\nUse "help [command]" for more information about a specific command.');
  }
};
