/**
 * Darkvenom v1 - Time Command
 * Displays the current time in different formats and timezones
 */

const { logger } = require('../utils/logger');

module.exports = {
  name: 'time',
  description: 'Display the current time in different formats',
  usage: 'time [format]',
  examples: [
    'time (shows current time)',
    'time utc (shows UTC time)',
    'time iso (shows ISO format)'
  ],
  
  /**
   * Execute the time command
   * @param {Array} args - Command arguments
   * @param {Object} botState - Current state of the bot
   */
  execute: async (args, botState) => {
    const now = new Date();
    const format = args[0]?.toLowerCase();
    
    switch (format) {
      case 'utc':
        logger.info(`Current UTC time: ${now.toUTCString()}`);
        break;
        
      case 'iso':
        logger.info(`Current time (ISO): ${now.toISOString()}`);
        break;
        
      case 'unix':
        logger.info(`Current Unix timestamp: ${Math.floor(now.getTime() / 1000)}`);
        break;
        
      default:
        logger.info(`Current local time: ${now.toLocaleString()}`);
        logger.info(`Current UTC time: ${now.toUTCString()}`);
        logger.info(`Current Unix timestamp: ${Math.floor(now.getTime() / 1000)}`);
    }
  }
};
