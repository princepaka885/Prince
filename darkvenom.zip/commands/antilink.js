/**
 * Darkvenom v1.1.1 - Antilink Command
 * Manages anti-link protection for groups
 */

const { logger } = require('../utils/logger');
const config = require('../config');

module.exports = {
  name: 'antilink',
  description: 'Manage anti-link protection for groups',
  usage: 'antilink <action> [option]',
  examples: [
    'antilink on',
    'antilink off',
    'antilink status',
    'antilink kick on',
    'antilink kick off',
    'antilink warn on',
    'antilink warn off',
    'antilink whitelist add example.com',
    'antilink whitelist remove example.com',
    'antilink whitelist list'
  ],
  
  /**
   * Execute the antilink command
   * @param {Array} args - Command arguments
   * @param {Object} botState - Current state of the bot
   */
  execute: async (args, botState) => {
    // Check if group functionality is enabled
    if (!config.group?.enabled) {
      logger.warn('Group functionality is required for antilink features');
      return;
    }

    // Check if user has admin privileges
    const isAdmin = checkAdminPrivileges();
    if (!isAdmin) {
      logger.warn('This command requires admin privileges');
      return;
    }
    
    // Using the prefix format as requested: >command action option
    // We're making our command handling support this format

    if (args.length === 0) {
      displayAntilinkHelp();
      return;
    }

    const action = args[0].toLowerCase();
    
    switch (action) {
      case 'on':
        enableAntilink();
        break;
        
      case 'off':
        disableAntilink();
        break;
        
      case 'status':
        displayAntilinkStatus();
        break;
        
      case 'kick':
        handleKickOption(args.slice(1));
        break;
        
      case 'warn':
        handleWarnOption(args.slice(1));
        break;
        
      case 'whitelist':
        handleWhitelistOption(args.slice(1));
        break;
        
      default:
        logger.warn(`Unknown antilink action: ${action}`);
        displayAntilinkHelp();
    }
  }
};

/**
 * Display help information for the antilink command
 */
function displayAntilinkHelp() {
  logger.info('===== Antilink Command Help =====');
  logger.info('Usage: >antilink <action> [option]');
  logger.info('');
  logger.info('Basic Actions:');
  logger.info('  >antilink on - Enable antilink protection');
  logger.info('  >antilink off - Disable antilink protection');
  logger.info('  >antilink status - Check current antilink settings');
  logger.info('');
  logger.info('Advanced Actions:');
  logger.info('  >antilink kick on - Enable automatic kicking for link senders');
  logger.info('  >antilink kick off - Disable automatic kicking');
  logger.info('  >antilink warn on - Enable warnings before kicking');
  logger.info('  >antilink warn off - Disable warnings');
  logger.info('');
  logger.info('Whitelist Management:');
  logger.info('  >antilink whitelist add <domain> - Add domain to whitelist');
  logger.info('  >antilink whitelist remove <domain> - Remove domain from whitelist');
  logger.info('  >antilink whitelist list - Show whitelisted domains');
  logger.info('================================');
}

/**
 * Enable antilink protection
 */
function enableAntilink() {
  logger.info('Enabling antilink protection...');
  logger.success('Antilink protection has been enabled');
  logger.info('Links shared in this group will now be detected');
}

/**
 * Disable antilink protection
 */
function disableAntilink() {
  logger.info('Disabling antilink protection...');
  logger.success('Antilink protection has been disabled');
  logger.info('Links can now be freely shared in this group');
}

/**
 * Display current status of antilink features
 */
function displayAntilinkStatus() {
  logger.info('===== Antilink Status =====');
  logger.info('Status: Enabled');
  logger.info('Automatic kick: Enabled');
  logger.info('Warnings: Enabled (3 warnings before kick)');
  logger.info('Whitelisted domains: 2');
  logger.info('- whatsapp.com');
  logger.info('- example.com');
  logger.info('===========================');
}

/**
 * Handle kick option for antilink
 * @param {Array} args - Additional arguments
 */
function handleKickOption(args) {
  if (args.length === 0) {
    logger.warn('Missing option for "kick". Use "on" or "off"');
    return;
  }
  
  const option = args[0].toLowerCase();
  
  if (option === 'on') {
    logger.info('Enabling automatic kick for link senders...');
    logger.success('Automatic kick has been enabled');
    logger.info('Users sending links will be automatically kicked');
  } else if (option === 'off') {
    logger.info('Disabling automatic kick for link senders...');
    logger.success('Automatic kick has been disabled');
    logger.info('Users sending links will not be automatically kicked');
  } else {
    logger.warn(`Invalid option for "kick": ${option}`);
    logger.info('Use "on" or "off"');
  }
}

/**
 * Handle warn option for antilink
 * @param {Array} args - Additional arguments
 */
function handleWarnOption(args) {
  if (args.length === 0) {
    logger.warn('Missing option for "warn". Use "on" or "off"');
    return;
  }
  
  const option = args[0].toLowerCase();
  
  if (option === 'on') {
    logger.info('Enabling warnings for link senders...');
    logger.success('Warnings have been enabled');
    logger.info('Users will receive 3 warnings before being kicked');
  } else if (option === 'off') {
    logger.info('Disabling warnings for link senders...');
    logger.success('Warnings have been disabled');
    logger.info('Users will be kicked immediately without warning');
  } else {
    logger.warn(`Invalid option for "warn": ${option}`);
    logger.info('Use "on" or "off"');
  }
}

/**
 * Handle whitelist options for antilink
 * @param {Array} args - Additional arguments
 */
function handleWhitelistOption(args) {
  if (args.length === 0) {
    logger.warn('Missing whitelist action. Use "add", "remove", or "list"');
    return;
  }
  
  const whitelistAction = args[0].toLowerCase();
  
  switch (whitelistAction) {
    case 'add':
      if (args.length < 2) {
        logger.warn('Missing domain to add to whitelist');
        return;
      }
      
      const domainToAdd = args[1].toLowerCase();
      logger.info(`Adding ${domainToAdd} to whitelist...`);
      logger.success(`Domain ${domainToAdd} has been added to the whitelist`);
      break;
      
    case 'remove':
      if (args.length < 2) {
        logger.warn('Missing domain to remove from whitelist');
        return;
      }
      
      const domainToRemove = args[1].toLowerCase();
      logger.info(`Removing ${domainToRemove} from whitelist...`);
      logger.success(`Domain ${domainToRemove} has been removed from the whitelist`);
      break;
      
    case 'list':
      logger.info('===== Whitelisted Domains =====');
      logger.info('- whatsapp.com');
      logger.info('- example.com');
      logger.info('==============================');
      break;
      
    default:
      logger.warn(`Invalid whitelist action: ${whitelistAction}`);
      logger.info('Use "add", "remove", or "list"');
  }
}

/**
 * Check if the current user has admin privileges
 * @returns {boolean} True if user has admin privileges
 */
function checkAdminPrivileges() {
  // In a real implementation, this would check the user's status
  // For this simulation, we'll always return true to allow testing
  return true;
}