/**
 * Darkvenom v1 - Commands Manager
 * Handles loading and registering all bot commands
 */

const fs = require('fs');
const path = require('path');
const { logger } = require('../utils/logger');
const { handleError } = require('../utils/errorHandler');

/**
 * Load all command modules
 * @returns {Object} Map of command names to command objects
 */
async function loadCommands() {
  try {
    const commands = {};
    const commandFiles = fs
      .readdirSync(__dirname)
      .filter(file => file !== 'index.js' && file.endsWith('.js'));
    
    logger.info(`Loading ${commandFiles.length} command modules...`);
    
    for (const file of commandFiles) {
      try {
        const commandName = path.basename(file, '.js');
        const command = require(path.join(__dirname, file));
        
        // Validate command structure
        if (!command.name || !command.description || !command.execute) {
          logger.warn(`Command ${commandName} is missing required properties and will not be loaded`);
          continue;
        }
        
        commands[command.name] = command;
        logger.debug(`Loaded command: ${command.name}`);
      } catch (error) {
        handleError(`Failed to load command file: ${file}`, error);
      }
    }
    
    return commands;
  } catch (error) {
    handleError('Failed to load commands', error);
    return {};
  }
}

module.exports = {
  loadCommands,
};
